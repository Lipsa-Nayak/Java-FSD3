package LinkedList;



public class LinkedListEx {
	 private Node head;

	    private static class Node {
	        int data;
	        Node next;

	        Node(int data) {
	            this.data = data;
	            this.next = null;
	        }
	    }

	    public void insert(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	        } else {
	            Node current = head;
	            while (current.next != null) {
	                current = current.next;
	            }
	            current.next = newNode;
	        }
	    }

	    public void delete(int key) {
	        if (head == null) {
	            return;
	        }

	        if (head.data == key) {
	            head = head.next;
	            return;
	        }

	        Node prev = null;
	        Node current = head;

	        while (current != null) {
	            if (current.data == key) {
	                prev.next = current.next;
	                return;
	            }
	            prev = current;
	            current = current.next;
	        }
	    }

	    public void display() {
	        Node current = head;
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }
	        System.out.println();
	    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedListEx linkedList = new LinkedListEx();
        linkedList.insert(1);
        linkedList.insert(2);
        linkedList.insert(3);
        linkedList.insert(4);
        linkedList.insert(5);

        System.out.println("Original list:");
        linkedList.display();

        int key = 3;
        linkedList.delete(key);

        System.out.println("List after deleting the first occurrence of " + key + ":");
        linkedList.display();
    }

	}


