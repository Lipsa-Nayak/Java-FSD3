package QueueJava;
import java.util.LinkedList;
import java.util.Queue;

public class QueueEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  // Create a queue using LinkedList
        Queue<String> queue = new LinkedList<>();

        // Insert elements into the queue
        queue.add("Flower");
        queue.add("Tree");
        queue.add("Plant");

        System.out.println("Initial Queue: " + queue);

        // Remove and retrieve the head of the queue
        String removedElement = queue.remove();
        System.out.println("Removed element: " + removedElement);
        System.out.println("Queue after removal: " + queue);

        // Insert a new element into the queue
        queue.add("Stem");
        System.out.println("Queue after insertion: " + queue);
    }

	}

