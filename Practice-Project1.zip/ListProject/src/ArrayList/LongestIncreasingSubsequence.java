package ArrayList;
import java.util.ArrayList;
import java.util.List;

public class LongestIncreasingSubsequence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] numbers = {10, 22, 9, 33, 21, 50, 41, 60};
        List<Integer> longestIncreasingSubsequence = findLongestIncreasingSubsequence(numbers);
        
        System.out.println("Longest Increasing Subsequence:");
        for (int num : longestIncreasingSubsequence) {
            System.out.print(num + " ");
        }
    }
    
    public static List<Integer> findLongestIncreasingSubsequence(int[] numbers) {
        int n = numbers.length;
        int[] lengths = new int[n]; // lengths[i] stores the length of the longest increasing subsequence ending at index i
        int[] previousIndices = new int[n]; // previousIndices[i] stores the index of the previous element in the longest increasing subsequence ending at index i
        
        for (int i = 0; i < n; i++) {
            lengths[i] = 1; // Initialize the length to 1 (each number is a subsequence of length 1)
            previousIndices[i] = -1; // Initialize the previous index to -1 (no previous element initially)
            
            for (int j = 0; j < i; j++) {
                if (numbers[j] < numbers[i] && lengths[j] + 1 > lengths[i]) {
                    lengths[i] = lengths[j] + 1;
                    previousIndices[i] = j;
                }
            }
        }
        
        // Find the index of the longest increasing subsequence's last element
        int maxLengthIndex = 0;
        for (int i = 1; i < n; i++) {
            if (lengths[i] > lengths[maxLengthIndex]) {
                maxLengthIndex = i;
            }
        }
        
        // Construct the longest increasing subsequence using the previous indices
        List<Integer> longestIncreasingSubsequence = new ArrayList<>();
        int currentIndex = maxLengthIndex;
        while (currentIndex != -1) {
            longestIncreasingSubsequence.add(0, numbers[currentIndex]);
            currentIndex = previousIndices[currentIndex];
        }
        
        return longestIncreasingSubsequence;
    }

	}



