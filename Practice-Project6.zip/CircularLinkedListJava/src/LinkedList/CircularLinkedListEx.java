package LinkedList;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head;

    public CircularLinkedList() {
        head = null;
    }

    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            newNode.next = newNode;
        } else if (data <= head.data) {
            Node last = head;
            while (last.next != head) {
                last = last.next;
            }
            newNode.next = head;
            last.next = newNode;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
    
}

public class CircularLinkedListEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 CircularLinkedList list = new CircularLinkedList();
	        list.insert(2);
	        list.insert(5);
	        list.insert(8);
	        list.insert(10);

	        System.out.println("Original List:");
	        list.display();

	        list.insert(7);
	        list.insert(12);

	        System.out.println("List after insertion:");
	        list.display();
	    }
	
	}


