package FourthSmallestElement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FourthSmallestElementEx {
	public static int findFourthSmallest(List<Integer> list) {
        if (list == null || list.size() < 4) {
            throw new IllegalArgumentException("List should contain at least four elements");
        }

        // Sort the list in ascending order
        Collections.sort(list);

        // Return the fourth element (at index 3)
        return list.get(3);
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 List<Integer> list = new ArrayList<>();
	        list.add(5);
	        list.add(2);
	        list.add(9);
	        list.add(1);
	        list.add(7);
	        list.add(3);
	        list.add(8);
	        list.add(6);
	        list.add(4);

	        int fourthSmallest = findFourthSmallest(list);
	        System.out.println("Fourth smallest element: " + fourthSmallest);
	    }
	

	}


